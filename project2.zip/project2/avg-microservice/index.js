const express = require('express');
const axios = require('axios');
const { addNumbers, getWindow, getAverage } = require('./windowStore');

const app = express();
const PORT = 9876;
const BASE_URL = 'http://20.244.56.144/evaluation-service';

// 🔐 Your Bearer Token
const AUTH_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJNYXBDbGFpbXMiOnsiZXhwIjoxNzQ3ODkxNjIyLCJpYXQiOjE3NDc4OTEzMjIsImlzcyI6IkFmZm9yZG1lZCIsImp0aSI6ImMzYzcxMTRlLWUyOTEtNGI0ZS1hYzQ1LTFlODEzY2UzNWExYSIsInN1YiI6IjIyMDAwMzA5OTFjc2VoQGdtYWlsLmNvbSJ9LCJlbWFpbCI6IjIyMDAwMzA5OTFjc2VoQGdtYWlsLmNvbSIsIm5hbWUiOiJib3BwYW5hIGRldmkgcHJhdmFsbGlrYSIsInJvbGxObyI6IjIyMDAwMzA5OTEiLCJhY2Nlc3NDb2RlIjoiYmVUSmpKIiwiY2xpZW50SUQiOiJjM2M3MTE0ZS1lMjkxLTRiNGUtYWM0NS0xZTgxM2NlMzVhMWEiLCJjbGllbnRTZWNyZXQiOiJTZ1FGR2hjY3ZSeUVUU0hiIn0.250Qi3T4hGlgG2P5zpwT1_D7u6a1KPoKfggM9R22K5c';

const ALLOWED_IDS = {
  p: 'primes',
  f: 'fibo',
  e: 'even',
  r: 'rand'
};

app.get('/numbers/:numberid', async (req, res) => {
  const { numberid } = req.params;

  if (!ALLOWED_IDS[numberid]) {
    return res.status(400).json({ error: 'Invalid number ID' });
  }

  const url = `${BASE_URL}/${ALLOWED_IDS[numberid]}`;
  const source = axios.CancelToken.source();

  const timeout = setTimeout(() => {
    source.cancel('Request timed out after 500ms');
  }, 500);

  let fetchedNumbers = [];

  try {
    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${AUTH_TOKEN}`
      },
      timeout: 500,
      cancelToken: source.token
    });

    if (Array.isArray(response.data.numbers)) {
      fetchedNumbers = response.data.numbers;
    }
  } catch (err) {
    clearTimeout(timeout);
    console.error('Fetch error:', err.message);

    return res.json({
      windowPrevState: getWindow(),
      windowCurrState: getWindow(),
      numbers: [],
      avg: getAverage()
    });
  }

  clearTimeout(timeout);

  const prev = addNumbers(fetchedNumbers);
  const curr = getWindow();
  const avg = getAverage();

  res.json({
    windowPrevState: prev,
    windowCurrState: curr,
    numbers: fetchedNumbers,
    avg
  });
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});